/*�Զ��������ļ���
  �ɶ���Ȥ�Ƽ����޹�˾ ��Ȩ����
  http://www.dfrobot.com.cn
  http://dfrobot.taobao.com/
  ���ܶ��壺ʵ�ִ���λ������ѡ�񴫸�����ˮ����ʽ��ͬʱ��������ʪ�ȡ������¶ȡ�ʪ�ȵ���λ������ʾ��
*/


#include <avr/eeprom.h>
#include "Free_Life.h"
#include <DHT.h>

#define DHTPIN 9 

//Uncomment whatever type you're using!
#define DHTTYPE DHT11   // DHT 11 
//#define DHTTYPE DHT22   // DHT 22  (AM2302)
//#define DHTTYPE DHT21   // DHT 21 (AM2301)

DHT dht(DHTPIN, DHTTYPE);


int magnetic_valve_state=0;

int dat[]={0x55,0xaa,0x00,0x00,0x00};


int Free_Life::moisture()
{
   int humidity_dat;
   humidity_dat=analogRead(2);   //humidity sensor connected to A2
   if(humidity_dat<500)humidity_dat=humidity_dat/5;
   else humidity_dat=100;
   return humidity_dat;
}


int Free_Life::CarbonRod()
{
   int humidity_dat;
   digitalWrite(2,LOW);
   digitalWrite(3,HIGH);
   delay(500);
   digitalWrite(2,HIGH);
   digitalWrite(3,LOW);
   humidity_dat=analogRead(0);     //CarbonRod connected to A0
   if(humidity_dat<500)humidity_dat=humidity_dat/5;
   else humidity_dat=100;
   return humidity_dat;
}


int Free_Life::ADJ() 
{
   int dat;
   dat=analogRead(1);             //humidity max connected to A1
   dat=map(dat, 0, 1023, 0, 100);//
   return dat;
}


void Free_Life::process(int temp) 
{
   switch(value){
      case 0xff: 
                 pump(moisture(),ADJ(),dht.readTemperature(),temp); //temp is environment temperature max
                 break;
      case 0xf0:
                 magnetic_valve(moisture(),ADJ(),dht.readTemperature(),temp); //temp is environment temperature max
                 break;
      case 0x0f: 
                 pump(CarbonRod(),ADJ(),dht.readTemperature(),temp); //temp is environment temperature max
                 break;
      case 0x00: 
                 magnetic_valve(CarbonRod(),ADJ(),dht.readTemperature(),temp); //temp is environment temperature max
                 break;
      default:                
                 pump(moisture(),ADJ(),dht.readTemperature(),temp); //temp is environment temperature max
                 break;
     }
   if(Serial.available()>0){
       dat[0]=Serial.read();
       dat[1]=Serial.read();
       dat[2]=Serial.read();
       dat[3]=Serial.read();
       dat[4]=Serial.read();
       SUM=dat[0]+dat[1]+dat[2]+dat[3];
       if(SUM==dat[4])
         {
           switch(dat[3])
             {
               case 0xff:value=0xff;break;
               case 0xf0:value=0xf0;break;
               case 0x0f:value=0x0f;break;
               case 0x00:value=0x00;break;
               default:value=0xff;break;
             }
           //eeprom_write_byte(addr, value);
         }
      
     }
}



void Free_Life::pump(int humidity,int humidity_max,float dht_t,int Temperature_max)  //
{
   digitalWrite(6,LOW);
   digitalWrite(5,LOW);
   digitalWrite(7,LOW);
   digitalWrite(4,LOW);
   if(humidity<=humidity_max&&dht_t<=Temperature_max)
    {
      digitalWrite(6,HIGH);
      digitalWrite(5,HIGH);
     }
   else
    {
      digitalWrite(6,LOW);
      digitalWrite(5,LOW);
     }
   delay(100);
}


void Free_Life::magnetic_valve(int humidity,int humidity_max,float dht_t,int Temperature_max)
{
    digitalWrite(6,LOW);
    digitalWrite(5,LOW);
    digitalWrite(7,LOW);
    digitalWrite(4,LOW);
    if(humidity<=humidity_max&&dht_t<=Temperature_max)
    {
     if(magnetic_valve_state==0)
       {
        digitalWrite(6,HIGH);
        digitalWrite(5,HIGH);
        digitalWrite(7,LOW);
        digitalWrite(4,LOW);
        delay(30);
        digitalWrite(6,LOW);
        digitalWrite(5,LOW);
        digitalWrite(7,LOW);
        digitalWrite(4,LOW);
        magnetic_valve_state=1;
       }
    }
    else
    {
     if(magnetic_valve_state==1)
       {             
        digitalWrite(7,HIGH); 
        digitalWrite(4,HIGH);    
        digitalWrite(5,LOW);
        digitalWrite(6,LOW);    
        delay(30);
        digitalWrite(7,LOW);
        digitalWrite(4,LOW);
        digitalWrite(5,LOW);
        digitalWrite(6,LOW);  
        magnetic_valve_state=0;
       }
     }
   delay(100);
}


void Free_Life::Initialization()
{
    pinMode(2,OUTPUT);
    pinMode(3,OUTPUT);
    pinMode(4,OUTPUT);
    pinMode(5,OUTPUT);
    pinMode(6,OUTPUT);
    pinMode(7,OUTPUT);
    digitalWrite(6,LOW);
    digitalWrite(4,LOW);
    digitalWrite(5,LOW);
    digitalWrite(7,LOW);
    dht.begin();
    value = 0xff;//eeprom_read_byte(addr);
}


void Free_Life::print()
{
    Serial.print(dht.readTemperature());   //
    Serial.print(",");
    if(value&0xf0==0xf0)Serial.print(moisture());
    else if(value|0x0f==0x0f)Serial.print(CarbonRod());
    Serial.print(",");
    Serial.print(dht.readHumidity());
    Serial.print(",");
    Serial.print(ADJ()); 
    Serial.print(",");
    switch(value)
         {
           case 0xff:Serial.println("ff");break;
           case 0x0f:Serial.println("0f");break;
           case 0xf0:Serial.println("f0");break;
           case 0x00:Serial.println("00");break;
         }
}
