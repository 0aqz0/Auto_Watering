/*�Զ��������ļ���
  �ɶ���Ȥ�Ƽ����޹�˾ ��Ȩ����
  http://www.dfrobot.com.cn
  http://dfrobot.taobao.com/
*/
#ifndef Free_Life_h
#define Free_Life_h
#include <avr/eeprom.h>
#include <arduino.h>



#define addr  0


class Free_Life
{
  public:
  uint8_t value,SUM;
  int moisture();
  int CarbonRod();
  int ADJ(); 
  void process(int temp);
  void pump(int humidity,int humidity_max,float dht_t,int Temperature_max);
  void magnetic_valve(int humidity,int humidity_max,float dht_t,int Temperature_max);
  void Initialization();
  void print();
};
#endif
 